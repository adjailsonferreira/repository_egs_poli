
#class para o requests com Cloud Firestore
class ProjetoController:

    def __init__(self):
        pass

    def newProject(self, model):
        pass
        
    def listProject(self):
        pass

    def getProjectDoc(self, doc):
        pass