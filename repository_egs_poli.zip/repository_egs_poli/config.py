config = {
    'apiKey': "AIzaSyBeI3TmqeOUihbuL9om1bUGA7MjBlHTEzg",
    'authDomain': "ecomp-observatorio.firebaseapp.com",
    'projectId': "ecomp-observatorio",
    'storageBucket': "ecomp-observatorio.appspot.com",
    'messagingSenderId': "879345948065",
    'appId': "1:879345948065:web:5e37abaf1826e2df2267e0",
    'measurementId': "G-N4J1J58PF5",
    'databaseURL': ''
}